import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AnimateCssPage } from './animate-css';

@NgModule({
  declarations: [
    AnimateCssPage,
  ],
  imports: [
    IonicPageModule.forChild(AnimateCssPage),
  ],
  exports: [
    AnimateCssPage
  ]
})
export class AnimateCssPageModule {}
