import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CalendarComponent } from './calendar';
import { PipesModule } from "../../pipes/pipes.module";

@NgModule({
  declarations: [
    CalendarComponent,
  ],
  imports: [
    PipesModule,
    IonicPageModule.forChild(CalendarComponent),
  ],
  exports: [
    CalendarComponent
  ]
})
export class CalendarComponentModule {}
